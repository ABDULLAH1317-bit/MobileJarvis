# Mobile Jarvis (Android)

फोन को बोलकर/लिखकर कंट्रोल करने वाला AI एजेंट। डिज़ाइन [OpenJarvis](https://github.com/open-jarvis/OpenJarvis)
(Apache-2.0) के विचारों पर आधारित है: local-first LLM + ReAct एजेंट लूप + टूल्स/स्किल्स।
इसमें OpenJarvis का कोड कॉपी नहीं किया गया है, यह मोबाइल के लिए नया लिखा गया Kotlin कोड है।
(अगर आप OpenJarvis का कोई हिस्सा सीधे जोड़ें, तो उसका Apache-2.0 LICENSE और attribution रखें।)

## चलाने के स्टेप
1. Android Studio (Koala या नया) में यह फोल्डर Open करें, Gradle Sync होने दें।
2. PC पर Ollama चलाएँ ताकि फोन उसे देख सके:
   `OLLAMA_HOST=0.0.0.0 ollama serve` और `ollama pull qwen2.5:7b`
   (फोन और PC एक ही WiFi पर हों)
3. ऐप फोन पर इंस्टॉल करें, "LLM सर्वर" में `http://<PC का IP>:11434` डालें।
4. "Accessibility चालू करें" → Mobile Jarvis → ON।
5. कमांड लिखें या 🎤 दबाएँ, फिर ▶ चलाओ।

## कैसे काम करता है
- `JarvisService.kt`: स्क्रीन पढ़ना (नंबर वाली लिस्ट), टैप, टाइप, स्क्रॉल, back/home
- `Agent.kt`: स्क्रीन → LLM → JSON क्रिया → अमल, ज़्यादा से ज़्यादा 15 स्टेप
- `Tools.kt`: ऐप खोलना, डायलर, SMS कंपोज़र, अलार्म, URL
- `LlmClient.kt`: कोई भी OpenAI-compatible endpoint (Ollama, llama.cpp, LM Studio, क्लाउड)

## सुरक्षा
- पासवर्ड फील्ड में टाइप ब्लॉक है।
- send/pay/buy/delete जैसे बटन से पहले स्क्रीन पर "हाँ/नहीं" पूछा जाता है।
- कॉल और SMS सिर्फ डायलर/कंपोज़र खोलते हैं; दबाना आपको पड़ता है।
- कुछ बैंकिंग ऐप Accessibility को ब्लॉक करते हैं, यह सामान्य है।

## स्थिति
यह शुरुआती स्केलेटन है। लिखते समय बिल्ड/टेस्ट नहीं हुआ, इसलिए पहली बार Sync/Build में छोटी गलतियाँ आ सकती हैं।
अगला कदम: ऑन-डिवाइस मॉडल (llama.cpp / MediaPipe), वेक-वर्ड, TTS जवाब।
