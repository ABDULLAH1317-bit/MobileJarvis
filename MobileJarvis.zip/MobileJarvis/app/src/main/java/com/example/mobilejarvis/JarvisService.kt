package com.example.mobilejarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** फोन की "आँख और हाथ": स्क्रीन पढ़ना, टैप, टाइप, स्क्रॉल। */
class JarvisService : AccessibilityService() {

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    /** मौजूदा स्क्रीन को नंबर वाली लिस्ट में बदलता है (यही LLM को भेजी जाती है)। */
    @Synchronized
    fun snapshot(): String {
        val root = rootInActiveWindow ?: return "(screen unavailable)"
        val found = ArrayList<AccessibilityNodeInfo>()
        collect(root, found)
        nodes = found
        val sb = StringBuilder("App: ${root.packageName}\n")
        found.forEachIndexed { i, n ->
            val label = (n.text ?: n.contentDescription ?: n.hintText ?: "").toString().take(60)
            val kind = when {
                n.isEditable -> "input"
                n.isClickable -> "button"
                n.isScrollable -> "scroll"
                else -> "text"
            }
            sb.append("[$i] $kind \"$label\"\n")
        }
        return sb.toString()
    }

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (n == null || !n.isVisibleToUser || out.size >= 80) return
        val hasLabel = !n.text.isNullOrBlank() || !n.contentDescription.isNullOrBlank()
        if (n.isClickable || n.isEditable || n.isScrollable || hasLabel) out.add(n)
        for (i in 0 until n.childCount) collect(n.getChild(i), out)
    }

    fun label(id: Int): String =
        nodes.getOrNull(id)?.let { (it.text ?: it.contentDescription ?: "").toString() } ?: ""

    fun tap(id: Int): String {
        val n = nodes.getOrNull(id) ?: return "error: no element $id"
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "ok"
        val r = Rect().also { n.getBoundsInScreen(it) }
        return if (gesture(r.centerX().toFloat(), r.centerY().toFloat())) "ok (gesture)" else "error: tap failed"
    }

    private fun gesture(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        return dispatchGesture(g, null, null)
    }

    fun type(id: Int, text: String): String {
        val n = nodes.getOrNull(id) ?: return "error: no element $id"
        if (n.isPassword) return "error: password fields are blocked"
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok" else "error: not an input field"
    }

    fun scroll(down: Boolean): String {
        val n = nodes.firstOrNull { it.isScrollable } ?: return "error: nothing scrollable"
        val a = if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (n.performAction(a)) "ok" else "error: scroll failed"
    }

    fun back(): String = if (performGlobalAction(GLOBAL_ACTION_BACK)) "ok" else "error"
    fun home(): String = if (performGlobalAction(GLOBAL_ACTION_HOME)) "ok" else "error"

    /** दूसरे ऐप के ऊपर "हाँ/नहीं" बॉक्स दिखाता है (संवेदनशील क्रिया से पहले)। */
    fun confirm(msg: String): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val ctx = this
        Handler(Looper.getMainLooper()).post {
            val wm = ctx.getSystemService(WINDOW_SERVICE) as WindowManager
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(0xEE222222.toInt())
                setPadding(40, 40, 40, 40)
            }
            fun finish(v: Boolean) { ok = v; wm.removeView(box); latch.countDown() }
            box.addView(TextView(ctx).apply { text = msg; setTextColor(Color.WHITE); textSize = 16f })
            box.addView(Button(ctx).apply { text = "हाँ"; setOnClickListener { finish(true) } })
            box.addView(Button(ctx).apply { text = "नहीं"; setOnClickListener { finish(false) } })
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, 0, PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.CENTER }
            wm.addView(box, lp)
        }
        latch.await(60, TimeUnit.SECONDS)
        return ok
    }

    companion object {
        @Volatile var instance: JarvisService? = null
    }
}
