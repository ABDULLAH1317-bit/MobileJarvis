package com.example.mobilejarvis

import android.content.Context
import org.json.JSONObject

/**
 * ReAct-शैली का लूप (OpenJarvis के native_react एजेंट जैसा विचार):
 * स्क्रीन देखो → LLM से अगली क्रिया पूछो → क्रिया चलाओ → दोहराओ।
 */
class Agent(
    private val ctx: Context,
    private val llm: LlmClient,
    private val log: (String) -> Unit,
) {
    @Volatile var cancelled = false

    private val system = """
You control an Android phone for the user. Each turn you get the goal, your previous steps, and the CURRENT screen as a numbered list.
Reply with ONE JSON object only, no other text:
{"thought":"short reasoning","action":"<name>","args":{...}}
Actions:
- open_app {"name":"WhatsApp"}
- tap {"id":3}
- type {"id":5,"text":"hello"}
- scroll {"direction":"down"} (or "up")
- back {} | home {} | wait {}
- open_url {"url":"https://..."}
- call {"number":"..."}  (opens the dialer; the user presses call)
- sms {"number":"...","text":"..."}  (opens the composer; the user presses send)
- set_alarm {"hour":7,"minute":30,"label":"..."}
- done {"message":"what you did, in the user's language"}
Rules: use element ids from the CURRENT screen only. Prefer direct actions (open_app, set_alarm, call, sms) over tapping around. Never enter passwords or payment details. If the goal is finished or impossible, use done.
""".trimIndent()

    fun run(goal: String): String {
        val history = ArrayList<String>()
        repeat(MAX_STEPS) { step ->
            if (cancelled) return "रोक दिया गया।"
            val svc = JarvisService.instance ?: return "Accessibility सेवा बंद है। पहले उसे चालू करें।"
            val prompt = "Goal: $goal\n\nPrevious steps:\n" +
                (history.takeLast(8).joinToString("\n").ifEmpty { "(none)" }) +
                "\n\nCurrent screen:\n" + svc.snapshot()

            val reply = try { llm.chat(system, prompt) } catch (e: Exception) { return "LLM error: ${e.message}" }
            val json = try {
                JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
            } catch (e: Exception) {
                history.add("${step + 1}. (model sent invalid JSON, retry)")
                return@repeat
            }

            val action = json.optString("action")
            val args = json.optJSONObject("args") ?: JSONObject()
            log("▶ ${json.optString("thought")}\n   $action $args")
            if (action == "done") return args.optString("message", "हो गया।")

            val result = execute(svc, action, args)
            history.add("${step + 1}. $action $args → $result")
            Thread.sleep(1200) // UI को बदलने का समय
        }
        return "अधिकतम स्टेप पूरे हो गए; काम अधूरा हो सकता है।"
    }

    private fun execute(svc: JarvisService, action: String, a: JSONObject): String = when (action) {
        "open_app" -> Tools.openApp(ctx, a.optString("name"))
        "tap" -> {
            val id = a.optInt("id", -1)
            val label = svc.label(id)
            if (SENSITIVE.any { label.contains(it, ignoreCase = true) } &&
                !svc.confirm("Jarvis \"$label\" दबाना चाहता है। अनुमति दें?")
            ) "denied by user" else svc.tap(id)
        }
        "type" -> svc.type(a.optInt("id", -1), a.optString("text"))
        "scroll" -> svc.scroll(a.optString("direction") != "up")
        "back" -> svc.back()
        "home" -> svc.home()
        "wait" -> "ok"
        "open_url" -> Tools.url(ctx, a.optString("url"))
        "call" -> Tools.call(ctx, a.optString("number"))
        "sms" -> Tools.sms(ctx, a.optString("number"), a.optString("text"))
        "set_alarm" -> Tools.alarm(ctx, a.optInt("hour"), a.optInt("minute"), a.optString("label", "Jarvis"))
        else -> "error: unknown action '$action'"
    }

    companion object {
        const val MAX_STEPS = 15
        // इन शब्दों वाले बटन दबाने से पहले यूज़र से पूछा जाएगा।
        val SENSITIVE = listOf(
            "send", "pay", "buy", "order", "delete", "confirm", "purchase", "transfer",
            "भेजें", "भेजो", "खरीदें", "हटाएँ", "भुगतान"
        )
    }
}
