package com.example.mobilejarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** किसी भी OpenAI-compatible सर्वर से बात करता है: Ollama, llama.cpp server, LM Studio, या क्लाउड API। */
class LlmClient(private val baseUrl: String, private val model: String, private val apiKey: String = "") {

    fun chat(system: String, user: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.1)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )
        val conn = (URL(baseUrl.trimEnd('/') + "/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 10_000
            readTimeout = 180_000
            setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val text = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (!ok) throw RuntimeException("HTTP ${conn.responseCode}: ${text.take(200)}")
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}
