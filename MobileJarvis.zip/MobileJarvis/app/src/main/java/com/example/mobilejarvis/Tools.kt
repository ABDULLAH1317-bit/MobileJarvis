package com.example.mobilejarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock

/** सीधे सिस्टम इंटेंट वाले टूल्स (OpenJarvis के "skills/tools" का मोबाइल रूप)। */
object Tools {

    private fun start(ctx: Context, i: Intent): String = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
    } catch (e: Exception) { "error: ${e.message}" }

    fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(q, 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(name, ignoreCase = true) }
            ?: return "error: app '$name' not found"
        val launch = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return "error: cannot launch"
        return start(ctx, launch)
    }

    // call/sms सिर्फ डायलर/कंपोज़र खोलते हैं; दबाना यूज़र को ही होगा।
    fun call(ctx: Context, number: String) = start(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    fun sms(ctx: Context, number: String, text: String) =
        start(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", text))
    fun url(ctx: Context, url: String) = start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    fun alarm(ctx: Context, hour: Int, minute: Int, label: String) = start(
        ctx,
        Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
    )
}
