package com.example.mobilejarvis

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var cmd: EditText
    private var agent: Agent? = null
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun field(hint: String, key: String, def: String) = EditText(this).apply {
            this.hint = hint
            setText(prefs.getString(key, def))
            setSingleLine()
            root.addView(this)
        }
        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
            root.addView(this)
        }

        val url = field("LLM सर्वर (Ollama / OpenAI-compatible)", "url", "http://192.168.1.10:11434")
        val model = field("मॉडल", "model", "qwen2.5:7b")
        val key = field("API key (वैकल्पिक)", "key", "")

        button("1) Accessibility चालू करें") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        cmd = EditText(this).apply { hint = "क्या करना है? जैसे: सुबह 7 बजे का अलार्म लगाओ" }
        root.addView(cmd)

        button("🎤 बोलकर बताएँ") {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            try { startActivityForResult(i, 1) }
            catch (e: Exception) { Toast.makeText(this, "वॉइस इनपुट उपलब्ध नहीं", Toast.LENGTH_SHORT).show() }
        }
        button("▶ चलाओ") {
            runGoal(cmd.text.toString(), url.text.toString(), model.text.toString(), key.text.toString())
        }
        button("■ रोको") { agent?.cancelled = true }

        scroll = ScrollView(this)
        logView = TextView(this).apply { textSize = 13f }
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun runGoal(goal: String, url: String, model: String, key: String) {
        if (goal.isBlank()) return
        prefs.edit().putString("url", url).putString("model", model).putString("key", key).apply()
        append("🎯 $goal")
        val a = Agent(applicationContext, LlmClient(url, model, key)) { append(it) }
        agent = a
        Thread { append("✅ " + a.run(goal)) }.start()
    }

    private fun append(s: String) = runOnUiThread {
        logView.append(s + "\n\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) {
            cmd.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "")
        }
    }
}
