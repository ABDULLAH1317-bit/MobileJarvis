plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mobilejarvis"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.mobilejarvis"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
// कोई बाहरी dependency नहीं: सिर्फ Android SDK + Kotlin stdlib
